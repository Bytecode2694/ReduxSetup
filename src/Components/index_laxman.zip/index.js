import React from 'react';
import {
    ActivityIndicator, FlatList,
    AppRegistry,
    Image,
    PixelRatio,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
    Dimensions,
    SafeAreaView,
    ScrollView,
    TextInput,
    Platform
} from 'react-native';
import {
    List,
    ListItem,
    Container,
    Content,
    Card,
    CardItem,


    // Header,
    Title,
    Button,
    Left,
    Right,
    Body,
    Icon,
    Toast
} from "native-base";
const menuIcon = require("../../../assets/icon-menu.png");
const camIcon = require("../../../assets/cam.png");
const logo = require("../../../assets/logo12.jpg");//amazon_PNG7
const { height } = Dimensions.get('window');

class Header extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
        //flexDirection='row', justifyContent='row', alignItems='column' alignItems: 'center', justifyContent: 'center'  boderColor: '#efefef', borderWidth: 2,
        //boderColor: '#efefef', borderWidth: 2,
        try {
            if (this.props.issearchbar === 'searchbar') {
                return (
                    <View style={styles.Alignheader}>

                        <View style={{
                            flex: 1, backgroundColor: '#fff', borderRadius: 5, flexDirection: 'row', padding: 2,


                            opacity: 0.8,

                            elevation: 20,
                        }}>
                            <View style={{ flex: 0.1, paddingLeft: 4, alignItems: 'flex-start', justifyContent: 'center' }}>
                                <Ionicons name='ios-search' size={30} color='#777777' />
                            </View>
                            <View style={{ flex: 0.93, paddingLeft: 5, alignItems: 'flex-start', justifyContent: 'flex-end' }}>
                                <TextInput
                                    style={styles.textInput}
                                    underlineColorAndroid={'transparent'}
                                    editable
                                    returnKeyType='go'
                                    blurOnSubmit={false}
                                    placeholder={'Search'}
                                    placeholderTextColor={"#777777"}
                                    // autoFocus
                                    selectionColor={"#777777"}
                                />
                            </View>
                        </View>


                    </View>
                );
            } else if (this.props.issearchbar === 'basicheader') {
                return (
                    <View style={styles.Alignheader}>
                        <View style={{ flex: 0.2, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }}>
                            <TouchableOpacity onPress={() => {
                                if (!(NavigateTo === "")) {
                                    this.props.navigation.navigate(this.props.NavigateTo);
                                }
                            }} >
                                <Image style={[styles.menuIcon, { color: this.props.Left.color }]} source={this.props.Left.leftcmp} />
                            </TouchableOpacity>
                        </View>
                        <View style={{ flex: 0.6, borderColor: 'red', borderWidth: 2, alignItems: 'center', justifyContent: 'center' }}>
                            <Text style={[styles.headerTitle, { color: this.props.Left.color }]}>{this.props.Body}</Text>
                        </View>

                        <View style={{ flex: 0.2, borderColor: 'red', borderWidth: 2, alignItems: 'flex-end', justifyContent: 'center' }}>
                            <Image style={styles.menuIcon} source={this.props.Right} />
                        </View>
                    </View>);
            } else {
                try {
                    return (
                        <View style={{ flex: 1 }}>
                            <View style={{ flexDirection: 'row', height: 60, backgroundColor: '#b9b9b9' }}>
                                <View style={{ flex: 0.1, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }}>
                                    <TouchableOpacity onPress={() => {
                                        if (!(NavigateTo === "")) {
                                            this.props.navigation.navigate(this.props.NavigateTo);
                                        }
                                    }} >
                                        <Image style={[styles.menuIcon]} source={this.props.Left.leftcmp} />
                                    </TouchableOpacity>
                                </View>
                                <View style={{ flex: 0.4, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }} >
                                    <TouchableOpacity>
                                        <Image style={[styles.logoIcon]} source={logo} />

                                    </TouchableOpacity>
                                </View>
                                <View style={{ flex: 0.4, borderColor: 'red', borderWidth: 2, alignItems: 'center', justifyContent: 'center' }} >

                                </View>
                                <View style={{ flex: 0.1, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }} >
                                    <Ionicons name="shopping-cart" size={30} color={'#fff'} />
                                </View>
                            </View>
                            <View style={{ flexDirection: 'row', height: 60, backgroundColor: '#efefef' }}>
                                <View style={styles.Alignheader}>
                                    <View style={{
                                        flex: 1, backgroundColor: '#fff', borderRadius: 5, flexDirection: 'row', padding: 2,


                                        opacity: 0.8,

                                        elevation: 20,
                                    }}>
                                        <View style={{ flex: 0.1, paddingLeft: 4, alignItems: 'flex-start', justifyContent: 'center' }}>
                                            <Ionicons name='ios-search' size={30} color='#777777' />
                                        </View>
                                        <View style={{ flex: 0.93, paddingLeft: 5, alignItems: 'flex-start', justifyContent: 'flex-end' }}>
                                            <TextInput
                                                style={styles.textInput}
                                                underlineColorAndroid={'transparent'}
                                                editable
                                                returnKeyType='go'
                                                blurOnSubmit={false}
                                                placeholder={'Search'}
                                                placeholderTextColor={"#777777"}
                                                // autoFocus
                                                selectionColor={"#777777"}
                                            />
                                        </View>
                                    </View></View>
                            </View>
                            <View style={{ flexDirection: 'row', height: 60, backgroundColor: '#d4d4d4' }}>
                                <View style={{ flex: 0.25, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }} >

                                </View>
                                <View style={{ flex: 0.25, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }} >

                                </View>
                                <View style={{ flex: 0.25, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }} >

                                </View>
                                <View style={{ flex: 0.25, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }} >

                                </View>
                            </View>
                        </View>
                    )
                } catch (error) {
                    console.log(error.message);
                }
            }
        } catch (error) {
            console.log(error.message);
        }
    }

}

export default class InfiniteList extends React.Component {
    constructor() {
        super();
        this.state = {
            data: [],
            page: 1,
            isLoading: false,
            showcheckmark: false,
            RadioSelectId: "",
        }
        // this.page = 1;
    }
    componentDidMount() {
        this.setState({ isLoading: true }, this.getDataByPage)
        //;
    }
    getDataByPage = async () => {
        const url = 'https://jsonplaceholder.typicode.com/photos?_limit=10&_page=' + this.state.page;
        fetch(url).then((response) => response.json())
            .then((responsejson) => {
                this.setState({ data: [...this.state.data, ...responsejson], isLoading: false })
            })
    }
    settext(value) {

        this.setState({ RadioSelectId: value, showcheckmark: true });

    }
    renderRow = ({ item }) => {
        return (
            <View>
                {/* <Image style={styles.itemImage}
                    source={{ uri: item.url }} />
                <Text style={styles.itemText}>{item.id}</Text> */}
                <ListItem
                    button
                    style={{ height: 60 }}
                    onPress={() => this.settext(item.title)}
                >
                    <Body>
                        <Text style={{ color: "#000" }}>
                            {item.title}
                        </Text>
                        <Text style={{ color: "#777" }}>
                            {item.url}
                        </Text>
                    </Body>
                    <Right>
                        <View>
                            {this.state.RadioSelectId === item.title && <Icon
                                active
                                name="checkmark"
                                style={styles.SelectedlistitemLeftIcon}
                            />}
                        </View>
                    </Right>
                </ListItem>
            </View>
        )
    }
    handleMore = async () => {
        //  this.page = this.page + 1;
        if (this.state.page <= 7) {
            this.setState({ isLoading: true, page: this.state.page + 1 }, this.getDataByPage);
        } else {
            this.setState({
                isLoading: false
            });
        }

    }

    listFooter = () => {

        return (
            this.state.isLoading ? <View style={styles.loader}>
                <ActivityIndicator size='large' />
            </View> : null
        )


    }
    render() {
        try {
            return (

                <SafeAreaView style={styles.container}>
                    <View style={styles.header1}>
                        {/*this.renderHeader(menuIcon, "CommonDropdownList", "Store Attendance", camIcon)*/}
                        <Header
                            issearchbar={"basicheader"}
                            Left={{ leftcmp: menuIcon, color: "red" }}
                            Right={camIcon}
                            Body={"Store Attendance"}
                            NavigateTo={"CommonDropdownList"}
                        />
                    </View>
                    <FlatList
                        style={styles.container}
                        data={this.state.data}
                        extraData={this.state.RadioSelectId}
                        renderItem={this.renderRow}
                        keyExtractor={(item, index) => index.toString()}
                        onEndReached={this.handleMore.bind(this)}
                        onEndReachedThreshold={0.5}
                        ListFooterComponent={this.listFooter}
                    />
                </SafeAreaView>
            );
        } catch (error) {
            console.log(error.message);
        }
    }
}


const styles = StyleSheet.create({
    // container: {
    //     marginTop: 20,
    //     backgroundColor: '#f5fcff'
    // },
    item: {
        backgroundColor: '#ccc',
        marginBottom: 10,
        borderBottomWidth: 1,
        marginTop: 24
    },
    itemText: {
        fontSize: 16,
        padding: 5
    },
    itemImage: {
        width: '100%',
        height: 200,
        resizeMode: 'cover'
    },
    loader: {
        marginTop: 10,
        alignItems: 'center'
    },


    //view header
    container: {
        ...StyleSheet.absoluteFillObject,
        flex: 1,
        // alignItems: 'stretch',
        backgroundColor: '#fff'
    },
    header1: {
        height: 60,
        paddingTop: 0,
        marginTop: 20,
        backgroundColor: '#111111',
        zIndex: 1001
    },
    Alignheader: {
        flex: 1,
        flexDirection: 'row',
        padding: 5,
        height: 60,

    },
    searchbar: {
        backgroundColor: '#777777'
    },
    menuIcon: {
        width: 30,
        height: 30,

    },
    logoIcon: {
        width: 80,
        height: 30,

    },
    headerTitle: {
        color: 'white',
        fontSize: 20
    },
    body: {
        flexGrow: 1,
        zIndex: 1000
    },
    menuContainer: {
        flex: 1,
        paddingTop: 30,
        paddingHorizontal: 40,
        //snapToEnd: false,
        backgroundColor: "#223f6b",

    },
    scrollview: {
        flexGrow: 1,
    },
    textInput: {
        padding: 0,
        margin: 0,
        flex: 1,
        color: "#000",
        height: 20,
        fontSize: 16,

    },

    box: {
        width: 50,
        height: 50,
        backgroundColor: '#fff',
        borderColor: '#696969',
        borderWidth: 1,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        shadowColor: '#696969',
        borderRadius: 4,
        shadowOffset: {
            width: 0,
            height: 3,
        },
        shadowOpacity: 0.27,
        shadowRadius: 4.65,
        elevation: 6,
    },
    box1: {
        width: 50,
        height: 50,
        backgroundColor: 'transparent',
    }
    ,
    avatarContainer: {
        borderColor: '#9B9B9B',
        borderWidth: 1 / PixelRatio.get(),
        justifyContent: 'center',
        alignItems: 'center',
    },
    avatar: {
        borderRadius: 75,
        width: 150,
        height: 150,
    },
    SelectedlistitemLeftIcon: {
        color: "#6bf9f2",
        fontSize: Platform.OS === "android" ? 24 : 34,
        fontWeight: "300"
    },



})